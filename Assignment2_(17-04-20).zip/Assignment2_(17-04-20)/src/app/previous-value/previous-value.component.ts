import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-previous-value',
  templateUrl: './previous-value.component.html',
  styleUrls: ['./previous-value.component.css']
})
export class PreviousValueComponent implements OnInit {

  text: any;

  constructor() { }

  ngOnInit(): void {
  }

  public textChanged(event) {
    console.log('changed', this.text, event);
    this.text = event;
  }

}
