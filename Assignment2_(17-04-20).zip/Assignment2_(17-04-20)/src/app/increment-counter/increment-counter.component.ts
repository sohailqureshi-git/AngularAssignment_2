import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-increment-counter',
  templateUrl: './increment-counter.component.html',
  styleUrls: ['./increment-counter.component.css']
})
export class IncrementCounterComponent implements OnInit {

  count = 0;

  constructor() { }

  ngOnInit(): void {
  }

  increment() {
    this.count++;
  }

  reset() {
    this.count = 0;
  }
}
