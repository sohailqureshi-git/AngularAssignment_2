import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Assignment2';
  
  productid = null;

  products = [
    {
      productid: 0,
      name: 'apple'
    },
    {
      productid: 1,
      name: 'mango'
    }
  ]
}
