import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousValueComponent } from './previous-value.component';

describe('PreviousValueComponent', () => {
  let component: PreviousValueComponent;
  let fixture: ComponentFixture<PreviousValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviousValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviousValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
