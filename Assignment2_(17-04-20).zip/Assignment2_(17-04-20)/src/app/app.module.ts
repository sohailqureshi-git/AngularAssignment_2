import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ImageGalleryComponent } from './image-gallery/image-gallery.component';
import { CardLayoutComponent } from './card-layout/card-layout.component';
import { IncrementCounterComponent } from './increment-counter/increment-counter.component';
import { PreviousValueComponent } from './previous-value/previous-value.component';
import { LoginRegistrationComponent } from './login-registration/login-registration.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseDetailsComponent } from './course-details/course-details.component';

@NgModule({
  declarations: [
    AppComponent,
    ImageGalleryComponent,
    CardLayoutComponent,
    IncrementCounterComponent,
    PreviousValueComponent,
    LoginRegistrationComponent,
    ReactiveFormsComponent,
    CourseListComponent,
    CourseDetailsComponent],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
