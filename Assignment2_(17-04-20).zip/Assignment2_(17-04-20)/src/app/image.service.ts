import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {    
  allImages = [];    
  
  getImages() {    
      return this.allImages = Imagesdelatils.slice(0);    
  }    
  
  getImage(id: number) {    
      return Imagesdelatils.slice(0).find(Images => Images.id == id)    
  }    
}    
const Imagesdelatils = [    
  { "id": 1, "categoryId": "1", "url": "assets/Images/nature1.jpg" },    
  { "id": 2, "categoryId": "1", "url": "assets/Images/nature2.jpg" },    
  { "id": 3, "categoryId": "1", "url": "assets/Images/nature3.jpg" },    
  { "id": 4, "categoryId": "2", "url": "assets/Images/animal1.jpg" },    
  { "id": 5, "categoryId": "2", "url": "assets/Images/animal2.jpg" },    
  { "id": 6, "categoryId": "3", "url": "assets/Images/bird1.jpg" },    
  { "id": 7, "categoryId": "3", "url": "assets/Images/bird2.jpg" },    
  { "id": 8, "categoryId": "3", "url": "assets/Images/bird3.jpg" }
]    