import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  constructor(  private router: Router) { }

  courseList = [
    {
      id: 1,
      name: 'Spring',
      detial : 'This is spring detail'
    },
    {
      id: 2,
      name: 'Hibernate',
      detial : 'This is Hibernate detail'
    },
    {
      id: 3,
      name: 'Junit',
      detial : 'This is Junit detail'
    },
       {
      id: 4,
      name: 'Html',
      detial : 'This is Html detail'
    },
    {
      id: 5,
      name: 'CSS',
      detial : 'This is CSS detail'
    },
  ];

  ngOnInit(): void {
  }

  getcourseDetail(id) {
    this.router.navigate(['users/admittance', id]);
  }

}
