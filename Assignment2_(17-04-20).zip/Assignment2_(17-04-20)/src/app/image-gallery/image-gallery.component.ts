import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { ImageService } from '../image.service';

@Component({
  selector: 'app-image-gallery',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.css']
})
export class ImageGalleryComponent implements OnChanges {

  images: any[];
  filterBy?: string = 'all'
  allImages: any[] = [];

  imageCategories = [
    {
      id: 1,
      name: 'Nature'
    },
    {
      id: 2,
      name: 'Animal'
    },
    {
      id: 3,
      name: 'Bird'
    },
  ];

  constructor(private imageService: ImageService) {
    this.allImages = this.imageService.getImages();
  }

  ngOnChanges() {
    this.allImages = this.imageService.getImages();
  }

  getFilteredImages(id) {
    let AllImages = this.imageService.getImages();
    this.allImages = AllImages.filter(image => image.categoryId == id);
    debugger
  }
}
